namespace WizardBase
{
    public delegate void WizardClickEventHandler(WizardControl sender, WizardClickEventArgs args);

    public delegate void WizardNextButtonClickEventHandler(WizardControl sender, WizardNextButtonClickEventArgs args);
}