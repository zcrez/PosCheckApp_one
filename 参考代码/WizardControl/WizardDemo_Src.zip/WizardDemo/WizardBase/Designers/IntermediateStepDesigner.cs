namespace WizardBase.Designers
{
    internal class IntermediateStepDesigner : WizardStepDesigner
    {
    }
}